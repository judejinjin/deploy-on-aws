-- Drop and recreate the TEST database with every build
DROP DATABASE IF EXISTS `TEST-routes`;

CREATE DATABASE IF NOT EXISTS `TEST-routes`;
use `TEST-routes`
